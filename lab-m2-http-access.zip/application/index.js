const express = require('express');
const app = express();
app.get('/', (req, res) => {
  res.send(`
    <div style="text-align:center; font-family:sans-serif; margin-top:50px;">
      <h1>🚀 Lab M2.04: SUCCESS</h1>
      <p>Public IP: 18.204.37.234</p>
      <p>Server Hostname: ${process.env.HOSTNAME}</p>
      <hr style="width:200px; margin: 20px auto;">
      <p>Nginx is successfully proxying to Node.js</p>
    </div>
  `);
});
app.listen(8080, () => console.log('App running on port 8080'));
