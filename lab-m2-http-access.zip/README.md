# Lab M2.04 - Enable HTTP Access
**Public IP:** 18.204.37.234
**Test URL:** http://18.204.37.234

### Process Followed:
1. Updated EC2 Security Group to allow inbound HTTP traffic on Port 80.
2. Installed Nginx and Node.js on Amazon Linux 2023.
3. Deployed an Express application listening on Port 8080.
4. Configured Nginx as a reverse proxy in /etc/nginx/conf.d/app.conf.
5. Restarted Nginx and verified the application was accessible via the public IP.

### Reflection:
Nginx acts as a reverse proxy to provide a layer of security. It handles the public-facing HTTP traffic (Port 80) and forwards it to the application (Port 8080), keeping the app port private and the server more secure.
